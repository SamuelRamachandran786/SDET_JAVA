#!/usr/bin/bash

# check_directory_empty() {
#     local directory=$1
#     local name=$2
#     if [ -z "$(ls -A $directory)" ]; then
#         echo $2 "-notexists"
#     else
#         echo $2 "-exists" 
#     fi
# }

check_directory_empty() {
    local directory=$1
    local name=$2
    if [ -d "$directory" ]; then
        echo $2 "-exists"
    else
        echo $2 "-notexists"
    fi
}

check_directory_log_extension(){
    log_directory="/home/coder/project/workspace/Project/logs"

# Specify the year you want to check for
target_year="2024"

# Check if a log file with the specified year exists
if find "$log_directory" -type f -name "*${target_year}*" | grep -q . ; then
    echo "Log -${target_year}"
    # Add your further actions here
else
    echo "Log file without ${target_year} "
    # Add your error handling or other actions here
fi
}
check_directory_rep_extension(){
    rep_directory="/home/coder/project/workspace/Project/reports"

# Specify the year you want to check for
target_year="2024"

# Check if a log file with the specified year exists
if find "$log_directory" -type f -name "*${target_year}*" | grep -q . ; then
    echo "Report -${target_year}"
    # Add your further actions here
else
    echo "Report file without ${target_year} "
    # Add your error handling or other actions here
fi
}
check_directory_scr_extension(){
    scr_directory="/home/coder/project/workspace/Project/screenshot"

# Specify the year you want to check for
target_year="2024"

# Check if a log file with the specified year exists
if find "$scr_directory" -type f -name "*${target_year}*" | grep -q . ; then
    echo "Screenshot -${target_year}"
    # Add your further actions here
else
    echo "Screenshot file without ${target_year} "
    # Add your error handling or other actions here
fi
}
rm -rf /home/coder/project/workspace/Project/screenshot
rm -rf /home/coder/project/workspace/Project/logs
rm -rf /home/coder/project/workspace/Project/reports
rm -rf /home/coder/project/log.log
touch /home/coder/project/log.log
cp /home/coder/project/workspace/selenium/EventHandler.java /home/coder/project/workspace/Project/src/test/java/utils/EventHandler.java
cd /home/coder/project/workspace/Project
mvn -q test
cp /home/coder/project/workspace/selenium/EventHandleDummy.java /home/coder/project/workspace/Project/src/test/java/utils/EventHandler.java
cat /home/coder/project/log.log
logdir="/home/coder/project/workspace/Project/logs"
scrdir="/home/coder/project/workspace/Project/screenshot"
reportsdir="/home/coder/project/workspace/Project/reports"
uistoredir="/home/coder/project/workspace/Project/src/test/java/uistore"
pagesdir="/home/coder/project/workspace/Project/src/test/java/pages"
runnerdir="/home/coder/project/workspace/Project/src/test/java/runner"
demodir="/home/coder/project/workspace/demo"

check_directory_empty $demodir "demo";
check_directory_empty $logdir "log";
check_directory_empty $scrdir "scr";
check_directory_empty $reportsdir "report";
check_directory_empty $uistoredir "uistore";
check_directory_empty $pagesdir "pages";
check_directory_empty $runnerdir "runner";
check_directory_log_extension $logdir "log";
check_directory_rep_extension $reportsdir "reports";
check_directory_scr_extension $scrdir "screenshot";

