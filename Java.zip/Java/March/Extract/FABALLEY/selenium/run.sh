#!/usr/bin/bash

check_directory_empty() {
    local directory=$1
    local name=$2
    if [ -z "$(ls -A $directory)" ]; then
        echo $2 "-notexists"
    else
        echo $2 "-exists" 
    fi
}
rm -rf /home/coder/project/workspace/Project/screenshots
rm -rf /home/coder/project/workspace/Project/logs
rm -rf /home/coder/project/workspace/Project/reports
rm -rf /home/coder/project/log.log
touch /home/coder/project/log.log
cp /home/coder/project/workspace/selenium/EventHandler.java /home/coder/project/workspace/Project/src/test/java/utils/EventHandler.java
cd /home/coder/project/workspace/Project
mvn -q test
cp /home/coder/project/workspace/selenium/EventHandleDummy.java /home/coder/project/workspace/Project/src/test/java/utils/EventHandler.java
cat /home/coder/project/log.log
logdir="/home/coder/project/workspace/Project/logs"
scrdir="/home/coder/project/workspace/Project/screenshots"
reportsdir="/home/coder/project/workspace/Project/reports"
featuredir="/home/coder/project/workspace/Project/features"
stepdir="/home/coder/project/workspace/Project/src/test/java/stepdefinition"
uistoredir="/home/coder/project/workspace/Project/src/test/java/uistore"
pagesdir="/home/coder/project/workspace/Project/src/test/java/pages"
runnerdir="/home/coder/project/workspace/Project/src/test/java/runner"


check_directory_empty $logdir "log";
check_directory_empty $scrdir "scr";
check_directory_empty $reportsdir "reports";
check_directory_empty $featuredir "feature";
check_directory_empty $stepdir "stepdefinition";
check_directory_empty $uistoredir "uistore";
check_directory_empty $pagesdir "pages";
check_directory_file $runnerdir "runner";
