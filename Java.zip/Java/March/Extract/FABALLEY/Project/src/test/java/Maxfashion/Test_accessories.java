package Maxfashion;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.events.WebDriverListener;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import utils.Base;
import utils.EventHandler;
import utils.LoggerHandler;
import utils.Reporter;
import utils.Screenshot;

public class Test_accessories extends Base{

	public final int IMPLICIT_WAIT_TIME=10;
	public final int PAGE_LOAD_TIME=30; 
	private ExtentReports reporter = Reporter.generateExtentReport();
    private ExtentTest test = reporter.createTest("Sleeper", "Product search"); 
   

	 @BeforeMethod
	    public void beforeMethod() throws MalformedURLException  {
		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setBrowserName("chrome");
		driver = new RemoteWebDriver(new URL("http://localhost:4444/"), dc);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICIT_WAIT_TIME));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PAGE_LOAD_TIME));
        driver.get("https://www.faballey.com/");
        WebDriverListener listener = new EventHandler();
		driver = new EventFiringDecorator<>(listener).decorate(driver);
	    }

		@Test
        public void testaccessories() throws Throwable {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            // js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("/html/body/div[23]/div/div/div[2]")));
		WebElement elementToHover = driver.findElement(By.xpath("/html/body/div[3]/header/nav/div[1]/ul/li[1]/a"));
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
		//Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[3]/header/nav/div[1]/ul/li[1]/div/div/ul[1]/li[3]/a")).click();
		Screenshot.captureScreenShot("screenshot");
        js.executeScript("window.scrollTo(0,500)");
        //Thread.sleep(7000);
		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div[2]/div[2]/div[5]/ul/li[1]/div[3]/button")).click();
		js.executeScript("window.scrollTo(0,500)");
		Thread.sleep(7000);
		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div[5]/div/div[2]/div/div[2]/div[4]/div[2]/a")).click();
		String mainWindowHandle = driver.getWindowHandle();
		  Set<String> allWindowHandles = driver.getWindowHandles();
		  for (String handle : allWindowHandles) {
			  if (!handle.equals(mainWindowHandle)) {
				  driver.switchTo().window(handle);
				  break;
			  }
		  }
		Thread.sleep(5000);
		driver.findElement(By.xpath("/html/body/div[3]/div[3]/div/div/div/div[1]/div[1]/div/ul/li[2]")).click();        
        Thread.sleep(7000);
		LoggerHandler.info("Clicked successful");
		test.log(Status.PASS,"Values passed");

        }
        @AfterMethod
		public void afterMethod() {
		//quit driver code
		driver.quit();
		reporter.flush();
		
	}
}
