// package pages;

// import java.io.IOException;
// import java.text.SimpleDateFormat;
// import java.time.Duration;
// import java.util.Date;
// import org.openqa.selenium.WebElement;

// import com.aventstack.extentreports.ExtentTest;
// import com.aventstack.extentreports.MediaEntityBuilder;
// import com.aventstack.extentreports.Status;
// import org.openqa.selenium.support.ui.WebDriverWait;
// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.Logger;
// import org.openqa.selenium.WebDriver;
// import utils.WebDriverHelper;
// import uistore.AppraiseUi;
// import utils.LoggerHandler;
// import utils.Reporter;

// public class AppraiseCar  {


//     private WebDriverHelper webDriverHelper;
//     LoggerHandler logger = new LoggerHandler();

//     Reporter reporter = new Reporter();
//     public AppraiseCar(WebDriver driver) {
//         webDriverHelper = new WebDriverHelper(driver);
        
//     }  

//     public void AppraiseCar(WebDriver driver)throws IOException {
    
           
//             ExtentTest test = Reporter.generateExtentReport().createTest("Feature Test", "Execution for Feature  Function");
              
//         try{
        
//             try{
            
//             webDriverHelper.ClickOnElement(AppraiseUi.appraiseMyCar);
//             test.log(Status.PASS, "Entered the value in search box");
//             logger.logInfo("Entered the value in search box");
            
//             }
//             catch(Exception ex){
//             ex.printStackTrace();
//             String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, " Error in Entered the value in search box");
//             test.fail("Failed to Entered the value in search box", MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
     
//         }

//             try{
            
//             webDriverHelper.ClickOnElement(AppraiseUi.vin);
//             test.log(Status.PASS, "Entered the value in search box");
//             logger.logInfo("Entered the value in search box");
            
//             }
//             catch(Exception ex){
//             ex.printStackTrace();
//             String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, " Error in Entered the value in search box");
//             test.fail("Failed to Entered the value in search box", MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
     
//         }
       
//         try{
//             webDriverHelper.sendKeys(AppraiseUi.vinNumber, "4Y1SL65848Z411439");
//             test.log(Status.PASS, "Click on the Feature option");
//             logger.logInfo("Feature option clicked");
                  

//         }catch(Exception ex){
//             ex.printStackTrace();
//             String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, " Error in Click on the Feature option");
//             test.fail("Failed to Click on the Feature option", MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
     
//         }
//         try{
            
//             webDriverHelper.ClickOnElement(AppraiseUi.carValue);
//             test.log(Status.PASS, "Entered the value in search box");
//             logger.logInfo("Entered the value in search box");
            
//             }
//             catch(Exception ex){
//             ex.printStackTrace();
//             String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, " Error in Entered the value in search box");
//             test.fail("Failed to Entered the value in search box", MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
     
//         }
  
        
//         }catch(Exception ex){
//             ex.printStackTrace();
//             String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, " Feature Test");
//             test.fail("Failed to Perform Feature Test", MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
     
//         }
           
        
//     }
// }