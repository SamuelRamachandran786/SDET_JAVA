// import org.apache.log4j.Logger;
// import org.apache.log4j.PropertyConfigurator;

// public class LogTest {
//     private static final Logger logger = Logger.getLogger(LogTest.class);

//     public static void main(String[] args) {
//         // Configure Log4j using the properties file
//         PropertyConfigurator.configure("log4j.properties");

//         // Set serial number for console4 pattern
//         System.setProperty("serial", "12345");

//         // Log messages using different patterns
//         logger.info("This is a sample log message using pattern (a).");
//         logger.info("This is a sample log message using pattern (b).");
//         logger.info("This is a sample log message using pattern (c).");
//         logger.info("This is a sample log message using pattern (d).");
//     }
// }
