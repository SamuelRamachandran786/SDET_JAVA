// package uistore;

// import org.openqa.selenium.By;

// public class AppraiseUi {
//     public static By appraiseMyCar = By.xpath("/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/a[3]");
// 	public static By vin = By.xpath("/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/button[2]/span[1]");
//     public static By vinNumber = By.xpath("//input[@name='vin-number']");
//     public static By carValue = By.xpath("/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[2]/div[1]/div[2]/div[1]/button[1]/span[1]");
// }
