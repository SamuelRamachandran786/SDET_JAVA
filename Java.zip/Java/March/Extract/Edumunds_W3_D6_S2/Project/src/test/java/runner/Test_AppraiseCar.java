package runner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;

public class Test_AppraiseCar {
    private static final Logger logger = Logger.getLogger(Test_AppraiseCar.class);

    @BeforeMethod
    public void beforeMethod() {
        // Configure Log4j using the properties file
        PropertyConfigurator.configure("log4j.properties");
    }

    @Test()
    public void TC_003() {
        // Log test case execution start
        logger.info("Test case TC_003 execution started.");

        // Perform actions (you can replace this with your actual test steps)
        logger.info("Performing actions...");

        // Log test case execution end
        logger.info("Test case TC_003 execution completed.");
    }

    @AfterMethod
    public void afterMethod() {
        // Log after method execution start
        logger.info("After method execution started.");

        // Perform any necessary cleanup (if required)

        // Log after method execution end
        logger.info("After method execution completed.");
    }
}
