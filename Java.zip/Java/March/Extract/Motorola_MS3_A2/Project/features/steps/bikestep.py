from behave import given, when, then, step
import allure
from pages.bikepage import BikePage

@allure.step
@given(u'I launch the browser and open the URL "https://www.acko.com/"')
def step_impl(context):
    try:
        print("Navigated to Acko Website....") 
        bike_search = BikePage(context.driver)
        bike_search.open()
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot_after_open", attachment_type=allure.attachment_type.PNG)
        
    except Exception as e:
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot", attachment_type=allure.attachment_type.PNG)
        raise e


@when(u'I click on "Claims" in the navigation bar')
def step_impl(context):
    try:
        print("Clicked the 'claims' in the navigation bar....")
        bike_search = BikePage(context.driver)
        bike_search.click_on_claims()
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot_after_open", attachment_type=allure.attachment_type.PNG)
        
    except Exception as e:
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot", attachment_type=allure.attachment_type.PNG)
        raise e 


@when(u'I hover on \'Bike\' and click on "How ACKO Claim works"')
def step_impl(context):
    try:
        print("Hover on the 'Bike' and click....")
        bike_search = BikePage(context.driver)
        bike_search.hover_on_Bike_and_click_how_acko_claim_works()
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot_after_open", attachment_type=allure.attachment_type.PNG)
        
    except Exception as e:
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot", attachment_type=allure.attachment_type.PNG)
        raise e 
    

@when(u'it switches to the new tab')
def step_impl(context):
    try:
        print("Switched to the new tab....")
        bike_search = BikePage(context.driver)
        bike_search.switch_to_new_tab()
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot_after_open", attachment_type=allure.attachment_type.PNG)
        
    except Exception as e:
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot", attachment_type=allure.attachment_type.PNG)
        raise e 

@when(u'I input the value "{bike_number}" in the search bar')
def step_impl(context, bike_number):
    try:
        print(f"Input the value: {bike_number}")
        bike_search = BikePage(context.driver)
        bike_search.enter_the_value(bike_number)
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot_after_open", attachment_type=allure.attachment_type.PNG)
        
    except Exception as e:
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot", attachment_type=allure.attachment_type.PNG)
        raise e


@when(u'I click on "check prices" button')
def step_impl(context):
    try:
        print("Clicked the 'check prices'....")
        bike_search = BikePage(context.driver)
        bike_search.click_on_check_prices()
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot_after_open", attachment_type=allure.attachment_type.PNG)
        
    except Exception as e:
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot", attachment_type=allure.attachment_type.PNG)
        raise e 

@then(u'I capture a screenshot')
def step_impl(context):
    try:
        print("Capture the 'screenshot'....")
        bike_search = BikePage(context.driver)
        bike_search.capture_screenshot_in_new_tab()
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot_after_open", attachment_type=allure.attachment_type.PNG)
        
    except Exception as e:
        allure.attach(context.driver.get_screenshot_as_png(), name="screenshot", attachment_type=allure.attachment_type.PNG)
        raise e    