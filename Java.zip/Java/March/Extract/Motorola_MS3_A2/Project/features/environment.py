from selenium import webdriver
from selenium.webdriver.support.event_firing_webdriver import EventFiringWebDriver
from utilities.eventhandler import EventHandler
from utilities.report import AllureReporter

def before_all(context):
    event_handler = EventHandler()
    options = webdriver.ChromeOptions()
    print("Instance created")
    options.add_argument("--start-maximized")
    remote_url = "http://localhost:4444"
    base_driver = webdriver.Remote(command_executor=remote_url, options=options)
    context.driver = EventFiringWebDriver(base_driver, event_handler)


def after_all(context):
    print("instance Destroyed")
    context.driver.quit()
    allure_reporter = AllureReporter("/home/coder/project/workspace/Project/Report") 
    allure_reporter.generate_report()

