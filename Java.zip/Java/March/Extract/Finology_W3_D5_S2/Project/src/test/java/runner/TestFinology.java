package runner;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.events.WebDriverListener;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import utils.EventHandler;

import java.net.URL;
import java.net.MalformedURLException;
import java.time.Duration;

public class TestFinology {

    @Test
    public void testPage() throws MalformedURLException {
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setBrowserName("chrome");
        WebDriver driver = new RemoteWebDriver(
                new URL("https://4444-cfddcdeabdafacccacbadbfbdcbcafe.premiumproject.examly.io/"), dc);
        // WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/"), dc);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
        driver.get("https://www.finology.in/");
        WebDriverListener listener = new EventHandler();
        driver = new EventFiringDecorator<>(listener).decorate(driver);

        WebElement letsBegin = driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/a[1]"));
        letsBegin.click();

        WebElement mobileNumber = driver.findElement(By.xpath("//input[@type='tel']"));
        mobileNumber.sendKeys("9876543210"); // corrected method name

        WebElement cntnue = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[2]/form[1]/div[1]/button[1]"));
        cntnue.click();

        driver.quit();
    }
}
