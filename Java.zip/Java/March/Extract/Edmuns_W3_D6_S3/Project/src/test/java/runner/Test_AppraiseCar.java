package runner;
import java.io.IOException;
import java.net.MalformedURLException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import pages.AppraiseCar;
import utils.Base;
import utils.Reporter;
public class Test_AppraiseCar extends Base {

   
    ExtentReports extent = new ExtentReports();
    AppraiseCar r;


    @Test()
    public void TC_003() throws IOException {
        
            navigateToURL(driver, prop);
            r = new AppraiseCar(driver);
            r.AppraiseCar(driver);
            
    }
    
    @BeforeMethod
    public void beforeMethod() throws MalformedURLException {
        openBrowser();
        extent = Reporter.generateExtentReport();
    }

    @AfterMethod
    public void afterMethod() {
        driver.quit();
        extent.flush();
    }
}

