package runner;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.events.WebDriverListener;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import utils.EventHandler;

import java.net.URL;
import java.net.MalformedURLException;
import java.time.Duration;

public class TestMagicBricks {

    @Test
    public void testPage() throws MalformedURLException {
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setBrowserName("chrome");
        WebDriver driver = new RemoteWebDriver(
                new URL("https://4444-cfddcdeabdafacccacbadbfbdcbcafe.premiumproject.examly.io/"), dc);
        // WebDriver driver = new RemoteWebDriver(new URL("http://localhost:4444/"), dc);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(15));
        driver.get("https://www.magicbricks.com/");
        WebDriverListener listener = new EventHandler();
        driver = new EventFiringDecorator<>(listener).decorate(driver);

        WebElement pg = driver.findElement(By.xpath("/html[1]/body[1]/section[1]/section[1]/div[1]/div[1]/div[2]/div[3]"));
        pg.click();

        WebElement occupancy = driver.findElement(By.xpath("/html[1]/body[1]/section[1]/section[1]/div[1]/div[1]/div[3]/div[2]/div[1]/span[1]"));
        occupancy.click();

        WebElement boys = driver.findElement(By.xpath("/html[1]/body[1]/section[1]/section[1]/div[1]/div[1]/div[3]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/label[1]"));
        boys.click();

        WebElement room = driver.findElement(By.xpath("/html[1]/body[1]/section[1]/section[1]/div[1]/div[1]/div[3]/div[2]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/label[1]"));
        room.click();
        
        WebElement search = driver.findElement(By.xpath("/html[1]/body[1]/section[1]/section[1]/div[1]/div[1]/div[3]/div[4]"));
        search.click();

        WebElement contact = driver.findElement(By.xpath("(//button[contains(text(),'Contact Owner')])[1]"));
        contact.click();
        
        System.out.println("Over");
        
        driver.quit();
    }
}
