#!/usr/bin/bash
cat /home/coder/project/log.log