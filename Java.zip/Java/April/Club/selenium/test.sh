#!/usr/bin/bash
logfile="/home/coder/project/log.log"

#Removing Files
rm -rf /home/coder/project/workspace/Project/screenshots
rm -rf /home/coder/project/workspace/Project/logs
rm -rf /home/coder/project/workspace/Project/reports
rm -rf "$logfile"
touch "$logfile"

#Execution
cp /home/coder/project/workspace/selenium/EventHandler.java /home/coder/project/workspace/Project/src/test/java/utils/EventHandler.java
cd /home/coder/project/workspace/Project
mvn -q test
cp /home/coder/project/workspace/selenium/EventHandleDummy.java /home/coder/project/workspace/Project/src/test/java/utils/EventHandler.java

# Redirect all output to log file
exec > >(tee -a /home/coder/project/log.log)
exec 2>&1

check_directory_empty() {
    local directory=$1
    local name=$2
    if [ -d "$directory" ]; then
        echo $2 "-exists" 
    else
        echo $2 "-notexists" 
    fi
}

check_directory_log_extension(){
    log_directory="/home/coder/project/workspace/Project/logs"

    # Specify the year you want to check for
    target_year="2024"

    # Check if a log file with the specified year exists
    if find "$log_directory" -type f -name "*${target_year}*" | grep -q . ; then
        echo "Log -${target_year}" 
        # Add your further actions here
    else
        echo "Log file without ${target_year} "
        # Add your error handling or other actions here
    fi
}

check_directory_rep_extension(){
    rep_directory="/home/coder/project/workspace/Project/reports"

    # Specify the year you want to check for
    target_year="2024"

    # Check if a log file with the specified year exists
    if find "$rep_directory" -type f -name "*${target_year}*" | grep -q . ; then
        echo "Report -${target_year}" 
        # Add your further actions here
    else
        echo "Report file without ${target_year} "
        # Add your error handling or other actions here
    fi
}

check_directory_scr_extension(){
    scr_directory="/home/coder/project/workspace/Project/screenshots"

    # Specify the year you want to check for
    target_year="2024"

    # Check if a log file with the specified year exists
    if find "$scr_directory" -type f -name "*${target_year}*" | grep -q . ; then
        echo "Screenshot -${target_year}"
        # Add your further actions here
    else
        echo "Screenshot file without ${target_year} "
        # Add your error handling or other actions here
    fi
}

logdir="/home/coder/project/workspace/Project/logs"
scrdir="/home/coder/project/workspace/Project/screenshots"
reportsdir="/home/coder/project/workspace/Project/reports"


check_directory_empty $logdir "log";
check_directory_empty $scrdir "scr";
check_directory_empty $reportsdir "report";
check_directory_log_extension $logdir "log";
check_directory_rep_extension $reportsdir "reports";
check_directory_scr_extension $scrdir "screenshots";

# Redirect all output to /dev/null
exec > /dev/null 2>&1
