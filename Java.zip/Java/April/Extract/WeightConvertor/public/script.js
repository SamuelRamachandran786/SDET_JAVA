// JavaScript for Weight Converter

function convert() {
    const weightInput = parseFloat(document.getElementById('weight').value);
    const toUnit = document.getElementById('toUnit').value;
    let convertedWeight;

    if (toUnit === 'g') {
        convertedWeight = weightInput * 1000; // Convert kilograms to grams
        const conversionFormula = '(1 Kilogram = 1000 Grams)';
        const convertedResult = `Result: ${convertedWeight.toFixed(3)} ${toUnit}`;
        document.getElementById('result').innerHTML = `${conversionFormula}<br><br>${convertedResult}`;
    } else if (toUnit === 'lbs') {
        convertedWeight = weightInput * 2.20462; // Convert kilograms to pounds
        const conversionFormula = '(1 Kilogram = 2.204 Pounds)';
        const convertedResult = `Result: ${convertedWeight.toFixed(3)} ${toUnit}`;
        document.getElementById('result').innerHTML = `${conversionFormula}<br><br>${convertedResult}`;
    } else {
        // Display error or handle invalid selection
        document.getElementById('result').innerHTML = "Please select a valid conversion unit.";
    }
}

// Add event listener to the Convert button
document.getElementById('convertBtn').addEventListener('click', convert);
