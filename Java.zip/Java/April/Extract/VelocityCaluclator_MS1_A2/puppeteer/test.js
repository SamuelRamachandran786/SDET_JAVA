const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    headless: false,
    args: ['--headless', '--disable-gpu', '--remote-debugging-port=9222', '--no-sandbox', '--disable-setuid-sandbox'],
  });

  // Test Case 1: Verify Page Title
  const page1 = await browser.newPage();
  try {
    await page1.goto('https://8081-eedbebdafebddfa311954238cfcfeebcebthree.premiumproject.examly.io/');
    await page1.waitForSelector('title', { timeout: 2000 });
    const title = await page1.title();
    if (title === 'Velocity Calculator') {
      console.log('TESTCASE:Verify_Page_Title:success');
    } else {
      console.log('TESTCASE:Verify_Page_Title:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Page_Title:failure');
  }

  // Test Case 2: Verify Distance Input Field
  const page2 = await browser.newPage();
  try {
    await page2.goto('https://8081-eedbebdafebddfa311954238cfcfeebcebthree.premiumproject.examly.io/');
    await page2.waitForSelector('#distance', { timeout: 2000 });
    const distanceInput = await page2.$('#distance');
    if (distanceInput) {
      console.log('TESTCASE:Verify_Distance_Input:success');
    } else {
      console.log('TESTCASE:Verify_Distance_Input:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Distance_Input:failure');
  }

  // Test Case 3: Verify Time Input Field
  const page3 = await browser.newPage();
  try {
    await page3.goto('https://8081-eedbebdafebddfa311954238cfcfeebcebthree.premiumproject.examly.io/');
    await page3.waitForSelector('#time', { timeout: 2000 });
    const timeInput = await page3.$('#time');
    if (timeInput) {
      console.log('TESTCASE:Verify_Time_Input:success');
    } else {
      console.log('TESTCASE:Verify_Time_Input:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Time_Input:failure');
  }

  // Test Case 4: Verify Calculate Velocity Button
  const page4 = await browser.newPage();
  try {
    await page4.goto('https://8081-eedbebdafebddfa311954238cfcfeebcebthree.premiumproject.examly.io/');
    await page4.waitForSelector('#calculateButton', { timeout: 2000 });
    const calculateButton = await page4.$('#calculateButton');
    if (calculateButton) {
      console.log('TESTCASE:Verify_Calculate_Velocity_Button:success');
    } else {
      console.log('TESTCASE:Verify_Calculate_Velocity_Button:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Calculate_Velocity_Button:failure');
  }

  // Test Case 5: Verify Velocity Result Output
  const page5 = await browser.newPage();
  try {
    await page5.goto('https://8081-eedbebdafebddfa311954238cfcfeebcebthree.premiumproject.examly.io/');
    await page5.waitForSelector('#velocityResult', { timeout: 2000 });
    await page5.waitForSelector('#distance', { timeout: 2000 });
    await page5.waitForSelector('#time', { timeout: 2000 });
    await page5.waitForSelector('#calculateButton', { timeout: 2000 });

    await page5.type("#distance", "100")
    await page5.type("#time", "10")
    await page5.click("#calculateButton")
    let resultContent = await page5.$eval("#velocityResult", (el) => el.innerText)
    if (resultContent.includes("10.00")) {
      console.log('TESTCASE:Verify_Velocity_Result_Output:success');
    } else {
      console.log('TESTCASE:Verify_Velocity_Result_Output:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Velocity_Result_Output:failure');
  }

  // Test Case: Verify Button Background Color
  const page6 = await browser.newPage();
  try {
    await page6.goto('https://8081-eedbebdafebddfa311954238cfcfeebcebthree.premiumproject.examly.io/');
    await page6.waitForSelector('#calculateButton', { timeout: 2000 });

    const backgroundColor = await page6.evaluate(() => {
      const button = document.getElementById('calculateButton');
      return getComputedStyle(button).getPropertyValue('background-color');
    });

    if (backgroundColor === 'rgb(25, 118, 210)') {
      console.log('TESTCASE:Verify_Calculate_Button_Background_Color:success');
    } else {
      console.log('TESTCASE:Verify_Calculate_Button_Background_Color:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Calculate_Button_Background_Color:failure');
  }

  // Test Case 7: Verify Heading Text
  const page7 = await browser.newPage();
  try {
    await page7.goto('https://8081-eedbebdafebddfa311954238cfcfeebcebthree.premiumproject.examly.io/');
    await page7.waitForSelector('h1', { timeout: 2000 });
    const headingText = await page7.evaluate(() => {
      const heading = document.querySelector('h1');
      return heading.innerText;
    });
    if (headingText === 'Velocity Calculator') {
      console.log('TESTCASE:Verify_Heading_Text:success');
    } else {
      console.log('TESTCASE:Verify_Heading_Text:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Heading_Text:failure');
  }

  finally {
    await page1.close();
    await page2.close();
    await page3.close();
    await page4.close();
    await page5.close();
    await page6.close();
    await page7.close();
  }

  await browser.close();
})();
