document.addEventListener("DOMContentLoaded", function () {
    const calculateButton = document.getElementById("calculateButton");
    const distanceInput = document.getElementById("distance");
    const timeInput = document.getElementById("time");
    const velocityResultParagraph = document.getElementById("velocityResult");

    function calculateVelocity() {
        const distance = parseFloat(distanceInput.value);
        const time = parseFloat(timeInput.value);
    
        if (isNaN(distance) && isNaN(time)) {
            velocityResultParagraph.innerText = "Please enter both distance and time.";
            return;
        }
    
        if (isNaN(distance)) {
            velocityResultParagraph.innerText = "Please enter a valid value for distance.";
            return;
        }
    
        if (isNaN(time)) {
            velocityResultParagraph.innerText = "Please enter a valid value for time.";
            return;
        }
    
        if (time === 0) {
            velocityResultParagraph.innerText = "Time cannot be zero.";
            return;
        }
    
        const velocity = distance / time;
        velocityResultParagraph.innerText = `Velocity: ${velocity.toFixed(2)} m/s`;
    }
    


    calculateButton.addEventListener("click", function () {
        calculateVelocity();
    });
});
