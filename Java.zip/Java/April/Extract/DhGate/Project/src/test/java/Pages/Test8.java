package Pages;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.events.WebDriverListener;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import utils.Base;
import utils.EventHandler;
import utils.Screenshot;
import utils.WebDriverHelper;
import utils.LoggerHandler;
import utils.Reporter;

public class Test8 extends Base {

    public final int IMPLICIT_WAIT_TIME = 10;
    public final int PAGE_LOAD_TIME = 30;
    private ExtentReports reporter = Reporter.generateExtentReport();
    private ExtentTest test = reporter.createTest("Offers", "Offer");
    private WebDriverHelper webDriverHelper;

    @BeforeMethod
    public void beforeMethod() throws MalformedURLException {
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setBrowserName("chrome");
        driver = new RemoteWebDriver(new URL("http://localhost:4444/"), dc);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICIT_WAIT_TIME));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PAGE_LOAD_TIME));
        driver.get("https://www.dhgate.com/");
        WebDriverListener listener = new EventHandler();
        driver = new EventFiringDecorator<>(listener).decorate(driver);
        webDriverHelper = new WebDriverHelper(driver);
    }

@Test
public void testwindows() throws Throwable {
    driver.findElement(By.xpath("//div[@spm-index='close']")).click();

    JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
    WebElement element = driver.findElement(By.xpath("//a[contains(text(),'Affiliate Program')]"));
    jsExecutor.executeScript("arguments[0].scrollIntoView(true);", element);
    jsExecutor.executeScript("arguments[0].click();", element);

    driver.findElement(By.xpath("(//span[contains(text(),'Get Started Now >>')])[3]")).click();

    driver.findElement(By.xpath("//span[contains(text(),'FAQ')]")).click();

    Screenshot.captureScreenShot("window");
}


    @AfterMethod
    public void afterMethod() {
        // quit driver code
        driver.quit();
        reporter.flush();

    }
}
