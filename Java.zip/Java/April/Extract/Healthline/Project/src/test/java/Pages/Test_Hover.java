package Pages;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.events.WebDriverListener;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import utils.Base;
import utils.EventHandler;
import utils.Screenshot;
import utils.WebDriverHelper;
import utils.LoggerHandler;
import utils.Reporter;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import java.util.Set;


public class Test_Hover extends Base {

    public final int IMPLICIT_WAIT_TIME = 10;
    public final int PAGE_LOAD_TIME = 30;
    private ExtentReports reporter = Reporter.generateExtentReport();
    private ExtentTest test = reporter.createTest("Offers", "Offer");

    @BeforeMethod
    public void beforeMethod() throws MalformedURLException {
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setBrowserName("chrome");
        driver = new RemoteWebDriver(new URL("http://localhost:4444/"), dc);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICIT_WAIT_TIME));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PAGE_LOAD_TIME));
        driver.get("https://www.healthline.com/");
        WebDriverListener listener = new EventHandler();
        driver = new EventFiringDecorator<>(listener).decorate(driver);
    }

    @Test
    public void testbrands() throws Throwable {

        WebElement elementToHover = driver.findElement(By.xpath("//span[contains(text(),'Health Conditions')]"));
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();

        driver.findElement(By.xpath("/html[1]/body[1]/div[3]/div[2]/div[3]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/ul[1]/li[2]/div[1]/div[2]/div[1]/ul[1]/li[13]/a[1]")).click();
 
        driver.findElement(By.xpath("(//button[@type='button'])[2]")).click();

        driver.findElement(By.xpath("/html[1]/body[1]/div[3]/div[2]/div[3]/div[6]/div[1]/div[1]/div[1]/div[3]/nav[1]/ul[1]/li[7]/a[1]")).click();

        Screenshot.captureScreenShot("Heart");

    }

    @AfterMethod
    public void afterMethod() {
        // quit driver code
        driver.quit();
        reporter.flush();
    }

}
