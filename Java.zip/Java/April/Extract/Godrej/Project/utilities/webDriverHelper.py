from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys


class WebDriverHelper:
    def __init__(self, driver):
        self.driver = driver

    def openPage(self, url):
        try:
            self.driver.get(url)
        except WebDriverException as e:
            print(e)
            raise Exception("Error in " + str(e))

    def clickElement(self, locator):
        try:
            element = self.driver.find_element(*locator)
            element.click()
        except WebDriverException as e:
            print(e)
            raise Exception("Error in " + str(e))

    def fillForm(self, locator, text):
        try:
            element = WebDriverWait(self.driver, 10).until(
                EC.visibility_of_element_located(locator)
            )
            element.send_keys(text)
        except TimeoutException as e:
            print(f"Timeout waiting for element to be visible: {str(e)}")
            raise Exception(f"Timeout waiting for element to be visible: {str(e)}")
        except WebDriverException as e:
            print(e)
            raise Exception("Error in " + str(e))

    def hoverOneElement(self, locator):
        try:
            element = self.driver.find_element(*locator)
            ActionChains(self.driver).move_to_element(element).perform()
        except WebDriverException as e:
            print(e)
            raise Exception("Error in " + str(e))

    def hoverTwoElements(self, firstLocator, secondLocator):
        try:
            firstElement = self.driver.find_element(*firstLocator)
            secondElement = self.driver.find_element(*secondLocator)
            actions = ActionChains(self.driver)
            actions.move_to_element(firstElement).move_to_element(secondElement).perform()
        except WebDriverException as e:
            print(e)
            raise Exception("Error in " + str(e))

    @staticmethod
    def send_keys_and_press_enter(driver, locator, text):
        element = driver.find_element(*locator)
        element.clear()  # Optional: Clear the input field before entering text
        element.send_keys(text)
        element.send_keys(Keys.ENTER)

    @staticmethod
    def switch_to_new_window(self):
        all_handles = self.driver.window_handles
        new_window_handle = all_handles[-1]
        self.driver.switch_to.window(new_window_handle)