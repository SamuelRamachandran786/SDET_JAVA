import os
import datetime
import subprocess

class AllureReporter:
    def __init__(self, report_directory):
        self.report_directory = report_directory

    def generate_report(self):
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        timestamped_folder = f"{self.report_directory}_{timestamp}"
        # behave_command = f"python3 -m behave -f allure_behave.formatter:AllureFormatter -o allure_results ./features"
        os.system(behave_command)
        allure_command = f"allure generate {self.report_directory} -o {timestamped_folder}"
        os.system(allure_command)

if __name__ == "__main__":
    report_directory = "/home/coder/project/workspace/Project/Report/allure-results"  
    allure_reporter = AllureReporter(report_directory)
    allure_reporter.generate_report()
