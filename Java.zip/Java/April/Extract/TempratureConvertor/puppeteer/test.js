const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    headless: false,
    args: ['--headless', '--disable-gpu', '--remote-debugging-port=9222', '--no-sandbox', '--disable-setuid-sandbox'],
  });


  const page1 = await browser.newPage();
  try {
    await page1.goto('https://8081-eedbebdafebddfa312546344faeaafacccfdbeeseven.premiumproject.examly.io/');
    await page1.waitForSelector('title', { timeout: 2000 });
    const title = await page1.title();
    if (title === 'Temperature Converter') {
      console.log('TESTCASE:Verify_Page_Title:success');
    } else {
      console.log('TESTCASE:Verify_Page_Title:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Page_Title:failure');
  }


  const page2 = await browser.newPage();
  try {
    await page2.goto('https://8081-eedbebdafebddfa312546344faeaafacccfdbeeseven.premiumproject.examly.io/');
    await page2.waitForSelector('#degrees', { timeout: 2000 });
    const degreesInput = await page2.$('#degrees');
    if (degreesInput) {
      console.log('TESTCASE:Verify_Degrees_Input:success');
    } else {
      console.log('TESTCASE:Verify_Degrees_Input:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Degrees_Input:failure');
  }


  const page3 = await browser.newPage();
  try {
    await page3.goto('https://8081-eedbebdafebddfa312546344faeaafacccfdbeeseven.premiumproject.examly.io/');
    await page3.waitForSelector('#unit', { timeout: 2000 });
    const unitInput = await page3.$('#unit');
    if (unitInput) {
      console.log('TESTCASE:Verify_Unit_Input:success');
    } else {
      console.log('TESTCASE:Verify_Unit_Input:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Unit_Input:failure');
  }


  const page4 = await browser.newPage();
  try {
    await page4.goto('https://8081-eedbebdafebddfa312546344faeaafacccfdbeeseven.premiumproject.examly.io/');
    await page4.waitForSelector('#result', { timeout: 2000 });
    const resultDisplay = await page4.$('#result');
    if (resultDisplay) {
      console.log('TESTCASE:Verify_Result_Display:success');
    } else {
      console.log('TESTCASE:Verify_Result_Display:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Result_Display:failure');
  }

  const page5 = await browser.newPage();
  try {
    await page5.goto('https://8081-eedbebdafebddfa312546344faeaafacccfdbeeseven.premiumproject.examly.io/');
    await page5.waitForSelector('button', { timeout: 2000 });
    const convertButton = await page5.$('button');
    if (convertButton) {
      console.log('TESTCASE:Verify_Convert_Button_Presence:success');
    } else {
      console.log('TESTCASE:Verify_Convert_Button_Presence:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Convert_Button_Presence:failure');
  }

  const page6 = await browser.newPage();
  try {
      await page6.goto('https://8081-eedbebdafebddfa312546344faeaafacccfdbeeseven.premiumproject.examly.io/'); 

      await page6.waitForSelector('#degrees');
      await page6.waitForSelector('#unit');
      await page6.waitForSelector('button');

      await page6.type('#degrees', '100');
      await page6.type('#unit', 'C');
      await page6.click('button');

      await page6.waitForSelector('#result');

      const resultText = await page6.$eval('#result', el => el.textContent);

      if (resultText.includes('212.00 degree Fahrenheit')) {
          console.log('TESTCASE:Verify_Conversion_From_Celsius_To_Fahrenheit:success');
      } else {
          console.log('TESTCASE:Verify_Conversion_From_Celsius_To_Fahrenheit:failure');
      }
  } catch (e) {
      console.log('TESTCASE:Verify_Conversion_From_Celsius_To_Fahrenheit:failure', e);
  } 

  const page7 = await browser.newPage();
  try {
    await page7.goto('https://8081-eedbebdafebddfa312546344faeaafacccfdbeeseven.premiumproject.examly.io/');
    await page7.waitForSelector('button', { timeout: 2000 });
    const buttonBackgroundColor = await page7.$eval('button', element => {
      return window.getComputedStyle(element).getPropertyValue('background-color');
    });
    if (buttonBackgroundColor === 'rgb(76, 175, 80)') {
      console.log('TESTCASE:Verify_Button_Background_Color:success');
    } else {
      console.log('TESTCASE:Verify_Button_Background_Color:failure');
    }
  } catch (e) {
    console.log('TESTCASE:Verify_Button_Background_Color:failure');
  }


  finally {
    await page1.close();
    await page2.close();
    await page3.close();
    await page4.close();
    await page5.close();
    await page6.close();
    await page7.close();
  }

  await browser.close();
})();
