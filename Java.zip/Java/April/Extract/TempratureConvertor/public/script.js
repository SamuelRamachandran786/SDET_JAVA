function convert() {
    // Get input values
    let degreesInput = document.getElementById('degrees').value.trim();
    let unitInput = document.getElementById('unit').value.trim().toLowerCase();

    // Validate input
    if (degreesInput === '' || (unitInput !== 'c' && unitInput !== 'f')) {
        alert('Please enter a valid temperature and unit (C/F).');
        return;
    }

    // Convert temperature
    let degrees = parseFloat(degreesInput);
    let result;

    if (unitInput === 'c') {
        result = celsiusToFahrenheit(degrees);
        document.getElementById('result').textContent = `${degrees} degree Celsius is ${result.toFixed(2)} degree Fahrenheit`;
    } else if (unitInput === 'f') {
        result = fahrenheitToCelsius(degrees);
        document.getElementById('result').textContent = `${degrees} degree Fahrenheit is ${result.toFixed(2)} degree Celsius`;
    }
}

function celsiusToFahrenheit(celsius) {
    return (celsius * 9/5) + 32;
}

function fahrenheitToCelsius(fahrenheit) {
    return (fahrenheit - 32) * 5/9;
}
