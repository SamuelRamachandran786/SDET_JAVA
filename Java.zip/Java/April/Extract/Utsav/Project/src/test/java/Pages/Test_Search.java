package Pages;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.events.WebDriverListener;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import utils.Base;
import utils.EventHandler;
import utils.Screenshot;
import utils.WebDriverHelper;
import utils.LoggerHandler;
import utils.Reporter;
import org.openqa.selenium.Keys;

public class Test_Search extends Base {

    public final int IMPLICIT_WAIT_TIME = 10;
    public final int PAGE_LOAD_TIME = 30;
    private ExtentReports reporter = Reporter.generateExtentReport();
    private ExtentTest test = reporter.createTest("Offers", "Offer");

    @BeforeMethod
    public void beforeMethod() throws MalformedURLException {
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setBrowserName("chrome");
        driver = new RemoteWebDriver(new URL("http://localhost:4444/"), dc);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICIT_WAIT_TIME));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PAGE_LOAD_TIME));
        driver.get("https://www.utsavfashion.com/");
        WebDriverListener listener = new EventHandler();
        driver = new EventFiringDecorator<>(listener).decorate(driver);
    }

    @Test
    public void testsearch() throws Throwable {

        WebElement input1 = driver.findElement(By.xpath("/html[1]/body[1]/main[1]/div[1]/header[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/form[1]/input[1]"));
        input1.sendKeys("Anarkali");
        input1.sendKeys(Keys.ENTER);

        driver.findElement(By.xpath("//span[contains(text(),'Indo-western')]")).click();
       
        driver.findElement(By.xpath("(//a[@class='product photo product-item-photo '])[1]")).click();

        driver.findElement(By.xpath("//a[contains(text(),'How To Measure')]")).click();

        Screenshot.captureScreenShot("Anarkali");
    }

    @AfterMethod
    public void afterMethod() {
        // quit driver code
        driver.quit();
        reporter.flush();

    }
}
