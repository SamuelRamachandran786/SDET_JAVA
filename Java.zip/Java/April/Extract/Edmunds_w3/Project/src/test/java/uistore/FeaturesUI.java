package uistore;

import org.openqa.selenium.By;

public class FeaturesUI {
    public static By new_car = By.xpath(
            "/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/nav[1]/div[2]/div[1]/ul[1]/li[1]/a[1]/span[1]/span[1]");
    public static By search = By.xpath("//input[@aria-label='Enter Make or Model']");
    public static By new_price = By.xpath("/html/body/div[1]/div/div[1]/div/nav/div[1]/div/div/div[2]/div[2]/button[1]");
    public static By feature = By.xpath(
            "/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/nav[1]/ul[1]/li[4]/a[1]");
}
