package pages;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utils.Screenshot;
import utils.WebDriverHelper;
import uistore.UsedcarUI;
import utils.LoggerHandler;
import utils.Reporter;

public class UsedCar {

    private WebDriverHelper webDriverHelper;
    LoggerHandler logger = new LoggerHandler();
    Reporter reporter = new Reporter();
    static {

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        System.setProperty("current.date.time", dateFormat.format(new Date()));
    }

    public UsedCar(WebDriver driver) {
        webDriverHelper = new WebDriverHelper(driver);

    }

    public void usedcar(WebDriver driver) throws IOException {

        ExtentTest test = Reporter.generateExtentReport().createTest("Features car Test",
                "Execution for Feature Car  Function");
        try {
            try {
                webDriverHelper.ClickOnElement(UsedcarUI.used_car);
                test.log(Status.PASS, "Click on the Used car link");
                logger.logInfo("Click on the Used car link");
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in Used car link");
                test.fail("Failed to click on the used car link",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }

            try {
                webDriverHelper.ClickOnElement(UsedcarUI.type);
                test.log(Status.PASS, "Click on the type");
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in type");
                test.fail("Failed to Perform type click",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }

            try {
                webDriverHelper.ClickOnElement(UsedcarUI.select_type);
                WebElement selectopt = driver.findElement((UsedcarUI.select_type));
                Select dropdown = new Select(selectopt);
                dropdown.selectByVisibleText("Diesel");

                Screenshot.getScreenShot(driver, "Diesel type selected");
                test.log(Status.PASS, "Diesel type selected");
                logger.logInfo("Diesel type selected");
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in Type selection ");
                test.fail("Failed in type selection",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }

            try {
                webDriverHelper.ClickOnElement(UsedcarUI.go_btn);
                test.log(Status.PASS, "Click on the Go button");
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in clicking Go button");
                test.fail("Failed to Perform Go click",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in Used car section");
            test.fail("Failed in Used car section",
                    MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
        }
    }
}
