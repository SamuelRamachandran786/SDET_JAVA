package uistore;

import org.openqa.selenium.By;

public class ShopUI {
    public static By shop = By.xpath("/html[1]/body[1]/div[1]/div[1]/main[1]/div[1]/div[2]/a[2]");
	public static By location = By.xpath("//input[@name='zip']");
	public static By select_make = By.id("usurp-make-select");
	public static By selectmakehonda = By.id("//option[contains(text(),'Honda')]");
	public static By select_model = By.id("usurp-model-select");
	public static By select_modelaccord = By.xpath("(//option[contains(text(),'Accord')])[1]");
	
   
}
