package pages;

import java.io.IOException;
import java.text.SimpleDateFormat;
import org.apache.log4j.Logger;
import utils.ReadPropertyFile;
import utils.ExcelReader;
import utils.LoggerHandler;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utils.Screenshot;
import utils.WebDriverHelper;
import java.util.Date;
import uistore.ShopUI;
import utils.Reporter;

public class Shop {
    WebDriver driver;
    LoggerHandler logger = new LoggerHandler();
    ExcelReader excelReader;
    WebDriverHelper webDriverHelper;
    ExcelReader file = new ExcelReader();
    Reporter reporter = new Reporter();
    // ReadPropertyFile configReader = new ReadPropertyFile();
    // String browserName = configReader.getBrowserName();
    static {

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        System.setProperty("current.date.time", dateFormat.format(new Date()));
    }

    public Shop(WebDriver driver) {
        this.driver = driver;
        webDriverHelper = new WebDriverHelper(driver);
        excelReader = new ExcelReader();
        logger.logInfo("Shop page opened");

    }

    public void ShopNew() throws IOException {

        ExtentTest test = Reporter.generateExtentReport().createTest("Shop New Test",
                "Execution for Shop page Function");

        try {
            // test.log(Status.PASS, "Browser opened");
            // String car_locations
            // =excelReader.ReadData("./testdata/Testdata.xlsx","Sheet1", 1, "location");
            try {

                webDriverHelper.ClickOnElement(ShopUI.shop);
                test.log(Status.PASS, "Click on Shop New");
                logger.logInfo(("Clicked on Shop New"));
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in clicking Shop New");
                test.fail("Failed to click Shop New",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }

            try {
                Thread.sleep(2000);
                webDriverHelper.ClickOnElement(ShopUI.select_make);
                test.log(Status.PASS, "Click on Make option");
                logger.logInfo(("Click on Make option"));
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in clicking Make option");
                test.fail("Failed to click Make option",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }
            try {
                Thread.sleep(2000);
                WebElement selectElement = driver.findElement(ShopUI.select_make); // Replace "dropdown" with your
                                                                                   // element's id
                // selectElement.click();
                Select dropdown = new Select(selectElement);
                dropdown.selectByVisibleText("Honda");
                // Thread.sleep(2000);
                // System.out.println("#######################################################");
                test.log(Status.PASS, "Click on Honda option");
                logger.logInfo(("Click on Honda option"));
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in clicking Make option");
                test.fail("Failed to click Shop New",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }

            try {

                webDriverHelper.ClickOnElement(ShopUI.select_model);
                test.log(Status.PASS, "Click on Model option");
                logger.logInfo(("Click on Model option"));
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in clicking Honda option");
                test.fail("Failed to click Model option",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }
            try {
                WebElement selectElements = driver.findElement(ShopUI.select_modelaccord); // Replace "dropdown" with
                                                                                           // your element's id
                selectElements.click();
                Select dropdowns = new Select(selectElements);
                dropdowns.selectByVisibleText("Accord");

                test.log(Status.PASS, "Click on Accord option");
                logger.logInfo(("Click on Accord option"));
            } catch (Exception ex) {
                ex.printStackTrace();
                String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Error in clicking Accord option");
                test.fail("Failed to click Accord",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            String base64Screenshot = Reporter.captureScreenshotAsBase64(driver, "Valid_Login_TC");
            test.fail("Failed to Shop New Testcase",
                    MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
        }
    }
}
