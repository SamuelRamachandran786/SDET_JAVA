package uistore;

import org.openqa.selenium.By;

public class UsedcarUI {
    public static By used_car = By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/nav[1]/div[2]/div[1]/ul[1]/li[2]/a[1]/span[1]/span[1]");
	public static By type = By.xpath("//button[@id='type_tab-tab']");
	public static By select_type = By.xpath("//select[@data-tracking-id = 'used_cars_index_mmz_type_select']");
	public static By min = By.id("used_cars_index_mmz_type_tab_min_price_select");
	public static By max = By.id("used_cars_index_mmz_type_tab_max_price_select");
	public static By loc = By.name("type_tab");
	public static By go_btn = By.xpath("//button[@data-tracking-id = 'used_cars_index_mmz_type_tab_submit']");
	public static By first_element = By.id("//*[@id='results-container']/ul/li[1]/div/div[2]/div/div[1]/div[1]/h2/a");
	public static By research = By.xpath("//*[@id='reviews']/div/div/section/a");

}