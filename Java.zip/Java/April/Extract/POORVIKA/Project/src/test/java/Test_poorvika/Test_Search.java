package Test_poorvika;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.events.WebDriverListener;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import utils.Base;
import utils.EventHandler;
import utils.Screenshot;
import utils.WebDriverHelper;
import utils.LoggerHandler;
import utils.Reporter;

public class Test_Search extends Base{

	public final int IMPLICIT_WAIT_TIME=10;
	public final int PAGE_LOAD_TIME=30; 
	private ExtentReports reporter = Reporter.generateExtentReport();
    private ExtentTest test = reporter.createTest("Search Item", "Product search"); 
   

	 @BeforeMethod
	    public void beforeMethod() throws MalformedURLException  {
		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setBrowserName("chrome");
		driver = new RemoteWebDriver(new URL("http://localhost:4444/"), dc);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICIT_WAIT_TIME));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PAGE_LOAD_TIME));
        driver.get("https://www.poorvika.com/");
        WebDriverListener listener = new EventHandler();
		driver = new EventFiringDecorator<>(listener).decorate(driver);
	    }

		@Test
        public void testsearch() throws Throwable {
		
		WebElement input1= driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div[1]/div[2]/div/div/form/input"));
        input1.click();
		input1.sendKeys("smart watch");
		input1.sendKeys(Keys.ENTER);
		System.out.println("Cotton dress");
		//Thread.sleep(5000);
		LoggerHandler.info("Clicked successful");
		Screenshot.captureScreenShot("screenshot");
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[4]/div/div/div/div[3]/div[4]/div/div[3]/div")).click();
        Set<String> windowHandles = driver.getWindowHandles();
         for (String windowHandle : windowHandles) {
             driver.switchTo().window(windowHandle);
            }
		driver.findElement(By.xpath("/html/body/div[1]/div/div[4]/div/div[1]/div[1]/div/div[2]/div[2]/div/div[3]/div/div/div/div[2]/div/button")).click();
		Thread.sleep(IMPLICIT_WAIT_TIME);
		test.log(Status.PASS,"Values passed");

        }
        @AfterMethod
		public void afterMethod() {
		//quit driver code
		driver.quit();
		reporter.flush();
		
	}
}
