package Pages;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringDecorator;
import org.openqa.selenium.support.events.WebDriverListener;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import utils.Base;
import utils.EventHandler;
import utils.Screenshot;
import utils.WebDriverHelper;
import utils.LoggerHandler;
import utils.Reporter;

public class Test_windows extends Base {

    public final int IMPLICIT_WAIT_TIME = 10;
    public final int PAGE_LOAD_TIME = 30;
    private ExtentReports reporter = Reporter.generateExtentReport();
    private ExtentTest test = reporter.createTest("Offers", "Offer");
    private WebDriverHelper webDriverHelper;

    @BeforeMethod
    public void beforeMethod() throws MalformedURLException {
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setBrowserName("chrome");
        driver = new RemoteWebDriver(new URL("http://localhost:4444/"), dc);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICIT_WAIT_TIME));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(PAGE_LOAD_TIME));
        driver.get("https://www.pepperfry.com/");
        WebDriverListener listener = new EventHandler();
        driver = new EventFiringDecorator<>(listener).decorate(driver);
        webDriverHelper = new WebDriverHelper(driver);
    }

    @Test
    public void testwindows() throws Throwable {

       WebElement input1 = driver.findElement(By.xpath("/html[1]/body[1]/app-root[1]/pf-header[1]/header[1]/div[2]/pf-header-main[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]"));
        input1.sendKeys("Fountains");
        input1.sendKeys(Keys.ENTER);

        driver.findElement(By.xpath("(//div[@class='image-cls-container ng-star-inserted'])[2]")).click(); 

        String mainWindowHandle = driver.getWindowHandle();
        Set<String> allWindowHandles = driver.getWindowHandles();
        for (String handle : allWindowHandles) {
            if (!handle.equals(mainWindowHandle)) {
                driver.switchTo().window(handle);
                break;
            }
        }

        driver.findElement(By.xpath("/html[1]/body[1]/app-root[1]/main[1]/app-vip[1]/div[1]/div[2]/div[2]/div[2]/section[1]/div[4]/pf-vip-cta[1]/div[1]/div[1]/div[2]/pf-button[1]/button[1]/div[1]/span[1]")).click(); 

        Screenshot.captureScreenShot("Fountains");
    }

    @AfterMethod
    public void afterMethod() {
        // quit driver code
        driver.quit();
        reporter.flush();

    }
}
